CREATE or replace procedure xxbcm_PO_InvoiceAmount AS
/*Author: Leena Sukhoo
  Creation Date: 4 Feb 2021
  Last Update Date:
  Last Updated by: Leena Sukhoo
  Version:1.0 
Procedure to generate summary of Orders with their corresponding list of distinct invoices and their total amount
*/
   cursor invoice_status_cur(l_po varchar2) is
   select PO.po_order_ref, 
       i.invoice_reference,
       i.invoice_status
      from XXBCM_Purchase_Order_t po, XXBCM_Purchase_Order_Line_t pl, xxbcm_supplier_t s, XXBCM_Invoice_t i
      where po.po_order_ref = pl.po_order_ref
      and po.supplier_name = s.supplier_name
      and pl.po_line_id = i.po_line_id
      and PO.po_order_ref = l_po
      group by PO.po_order_ref, i.invoice_reference, i.invoice_status;
   cursor po_list_cur is
   select distinct PO.po_order_ref 
      from XXBCM_Purchase_Order_t po;   
   cursor PO_invoice_cur is
      select distinct 
      PO.po_order_ref,
      to_number(substr(PO.po_order_ref,3,length(PO.po_order_ref))) Order_Reference,
      po.order_date,
      to_char(po.order_date,'Mon-yy') Order_Period,
      s.supplier_name,
      to_char(po.order_total_amount,'fm99,999,990.00') order_total_amount,
      po.order_status,
      i.invoice_reference,
      --i.invoice_amount
      to_char(Invoice_tot.Invoice_Total_Amount,'fm99,999,990.00') Invoice_Total_Amount,
      i.invoice_status
      from XXBCM_Purchase_Order_t po, XXBCM_Purchase_Order_Line_t pl, xxbcm_supplier_t s, XXBCM_Invoice_t i,
      (
      select PO.po_order_ref, 
       i.invoice_reference,
      po.order_total_amount,
      sum(i.invoice_amount) Invoice_Total_Amount
      from XXBCM_Purchase_Order_t po, XXBCM_Purchase_Order_Line_t pl, xxbcm_supplier_t s, XXBCM_Invoice_t i
      where po.po_order_ref = pl.po_order_ref
      and po.supplier_name = s.supplier_name
      and pl.po_line_id = i.po_line_id
      group by PO.po_order_ref, i.invoice_reference,po.order_total_amount 
      ) Invoice_tot
      where po.po_order_ref = pl.po_order_ref
      and po.supplier_name = s.supplier_name
      and pl.po_line_id = i.po_line_id
      and PO.po_order_ref = Invoice_tot.po_order_ref
      /*considering records having an invoice reference*/
      and i.invoice_reference = Invoice_tot.invoice_reference
      order by po.order_date desc;
      l_temp_pos_end number := 1;
      l_temp_word varchar2(1000);
      l_final_word varchar2(1000);
      rec_po_invoice PO_invoice_cur%ROWTYPE;
      rec_invoice_status invoice_status_cur%ROWTYPE;
      l_count number := 0;
      l_status_paid number := 0;
      l_status_pending number := 0;
      l_status_verify number := 0;
   BEGIN
    delete from xxbcm_PO_Invoice_Tot;
    OPEN PO_invoice_cur;
    FETCH PO_invoice_cur into rec_po_invoice;
    l_temp_word := ' ';
    l_temp_pos_end := 1;
    WHILE (PO_invoice_cur%FOUND) 
    LOOP
      l_temp_word := rec_po_invoice.supplier_name;
      WHILE (l_temp_pos_end > 0)
      LOOP
       --position of last letter in word
       l_temp_pos_end := instr(l_temp_word,' ') - 1; 
       l_final_word := l_final_word || upper(substr(l_temp_word,1,1)) || lower(substr(l_temp_word,2,instr(l_temp_word,' ')-1));
       l_temp_word := substr(l_temp_word, (l_temp_pos_end + 2), length(l_temp_word));
       IF (l_temp_pos_end < 0) then
        l_final_word := l_final_word || lower(substr(l_temp_word,2,length(l_temp_word)));
       END IF;
      END LOOP; 
      /*check invoice status*/
      open invoice_status_cur(rec_po_invoice.po_order_ref);
      FETCH invoice_status_cur into rec_invoice_status;
      WHILE (invoice_status_cur%FOUND)--(PO_invoice_cur%FOUND) 
      LOOP
        if (rec_invoice_status.invoice_status = 'Paid') then
           l_status_paid := l_status_paid + 1;
        else
            if (rec_invoice_status.invoice_status = 'Pending') then
              l_status_pending := l_status_pending + 1; 
            else
              if (rec_invoice_status.invoice_status is null) then
                 l_status_verify := l_status_verify + 1;
              end if;  
            end if;  
        end if;   
        FETCH invoice_status_cur into rec_invoice_status;
      END LOOP;
      close invoice_status_cur;
      if (l_status_paid > 0) and (l_status_pending = 0) and (l_status_verify = 0) then
        insert into xxbcm_PO_Invoice_Tot values (rec_po_invoice.order_reference, rec_po_invoice.order_period, l_final_word, 
        rec_po_invoice.order_Total_Amount,rec_po_invoice.order_status,rec_po_invoice.invoice_reference,
        rec_po_invoice.invoice_total_amount,'OK');
        dbms_output.put_line(rec_po_invoice.order_reference||'|'||rec_po_invoice.order_period||'|'||l_final_word||'|'||rec_po_invoice.order_Total_Amount
         ||'|'||rec_po_invoice.order_status||'|'||rec_po_invoice.invoice_reference||'|'||rec_po_invoice.invoice_total_amount||'|'
         ||'Paid');
      else
        if (l_status_pending > 0) then
          insert into xxbcm_PO_Invoice_Tot values (rec_po_invoice.order_reference, rec_po_invoice.order_period, l_final_word, 
          rec_po_invoice.order_Total_Amount,rec_po_invoice.order_status,rec_po_invoice.invoice_reference,
          rec_po_invoice.invoice_total_amount,'To follow up');
          dbms_output.put_line(rec_po_invoice.order_reference||'|'||rec_po_invoice.order_period||'|'||l_final_word||'|'||rec_po_invoice.order_Total_Amount
         ||'|'||rec_po_invoice.order_status||'|'||rec_po_invoice.invoice_reference||'|'||rec_po_invoice.invoice_total_amount||'|'
         ||'To follow up');
         else
          if (l_status_verify > 0) then
             insert into xxbcm_PO_Invoice_Tot values (rec_po_invoice.order_reference, rec_po_invoice.order_period, l_final_word, 
             rec_po_invoice.order_Total_Amount,rec_po_invoice.order_status,rec_po_invoice.invoice_reference,
             rec_po_invoice.invoice_total_amount,'To verify');
             dbms_output.put_line(rec_po_invoice.order_reference||'|'||rec_po_invoice.order_period||'|'||l_final_word||'|'||rec_po_invoice.order_Total_Amount
             ||'|'||rec_po_invoice.order_status||'|'||rec_po_invoice.invoice_reference||'|'||rec_po_invoice.invoice_total_amount||'|'
             ||'To verify');
          end if;
        end if;
      end if;
      l_temp_pos_end := 1;
      l_temp_word := ' ';
      l_final_word := ' ';
      l_status_paid := 0;
      l_status_pending := 0;
      l_status_verify := 0;
      FETCH PO_invoice_cur into rec_po_invoice;
    END LOOP;
    close PO_invoice_cur; 
   END;
/