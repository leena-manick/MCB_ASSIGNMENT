CREATE or replace procedure xxbcm_third_High_OrderAmt AS
/*Author: Leena Sukhoo
  Creation Date: 4 Feb 2021
  Last Update Date:
  Last Updated by: Leena Sukhoo
  Version:1.0 
Procedure to generate the THIRD (3rd) highest Order Total Amount
*/
 cursor po_cur(l_po varchar2) is 
      select distinct 
      PO.po_order_ref,
      to_number(substr(PO.po_order_ref,3,length(PO.po_order_ref))) Order_Reference,
      PO_Date.month ||PO_Date.Day||', '||PO_Date.Year Order_Date,
      upper(s.supplier_name) Supplier_Name,
      to_number(to_char(po.order_total_amount,'fm99999990.90')) Order_Total_Amount,
      po.order_status,
      i.invoice_reference
      from XXBCM_Purchase_Order_t po, XXBCM_Purchase_Order_Line_t pl, xxbcm_supplier_t s, XXBCM_Invoice_t i,
      (select PO_Order_Ref,
              to_char(TO_DATE(EXTRACT(MONTH FROM po.order_date), 'MM'), 'MONTH') Month,
              to_char(po.order_date,'dd') Day,
              to_char(po.order_date,'yyyy') Year
       from XXBCM_Purchase_Order_t po
      ) PO_Date
      where po.po_order_ref = pl.po_order_ref
      and po.supplier_name = s.supplier_name
      and pl.po_line_id = i.po_line_id
      and PO_Date.po_order_ref = po.po_order_ref
      and invoice_reference is not null
      and po.po_order_ref = l_po;
 cursor po_cur2(l_po varchar2) is 
      select distinct 
      /*PO.po_order_ref,*/
      to_number(substr(PO.po_order_ref,3,length(PO.po_order_ref))) Order_Reference,
      PO_Date.month ||PO_Date.Day||', '||PO_Date.Year Order_Date,
      upper(s.supplier_name) Supplier_Name,
      to_number(to_char(po.order_total_amount,'fm99999990.90')) Order_Total_Amount,
      po.order_status
      from XXBCM_Purchase_Order_t po, XXBCM_Purchase_Order_Line_t pl, xxbcm_supplier_t s, XXBCM_Invoice_t i,
      (select PO_Order_Ref,
              to_char(TO_DATE(EXTRACT(MONTH FROM po.order_date), 'MM'), 'MONTH') Month,
              to_char(po.order_date,'dd') Day,
              to_char(po.order_date,'yyyy') Year
       from XXBCM_Purchase_Order_t po
      ) PO_Date
      where po.po_order_ref = pl.po_order_ref
      and po.supplier_name = s.supplier_name
      and pl.po_line_id = i.po_line_id
      and PO_Date.po_order_ref = po.po_order_ref
      and invoice_reference is not null
      and po.po_order_ref = l_po;     
 cursor third_high_cur is
 SELECT po_order_ref--order_total_amount
 FROM (select ordAmt.*, rownum rnum from
             (select * from XXBCM_Purchase_Order_t ORDER BY order_total_amount DESC) ordAmt
      where rownum <= 3 )
 WHERE rnum >= 3; 
 l_third_high varchar2(20) := ' ';
 l_invoice varchar2(2000) := ' ';
 rec_po po_cur%ROWTYPE;
 rec_po2 po_cur2%ROWTYPE;    
begin
  open third_high_cur;
  fetch third_high_cur into l_third_high;
  close third_high_cur;
  open po_cur(l_third_high); 
  fetch po_cur into rec_po;
  open po_cur2(l_third_high); 
  fetch po_cur2 into rec_po2;
  if (po_cur%NOTFOUND) then
    dbms_output.put_line('Data Error');
  else  
     while (po_cur%FOUND)
     loop
       l_invoice := l_invoice||rec_po.invoice_reference||',';
       fetch po_cur into rec_po;
     end loop;
     close po_cur;
     if (substr(l_invoice, length(l_invoice), 1)) = ',' then
         l_invoice := substr(l_invoice,1,(length(l_invoice)-1));
     end if;
     if (po_cur2%NOTFOUND) then
        dbms_output.put_line('Data Error');
     else
        --dbms_output.put_line(l_third_high||':'||l_invoice);
        dbms_output.put_line('PO   Date                           Supplier               Amount  Status  Invoices');
        dbms_output.put_line(rec_po2.Order_Reference||'   '||rec_po2.Order_Date ||' '||rec_po2.Supplier_Name||' '||
        rec_po2.Order_Total_Amount||' '||rec_po2.order_status||' '||l_invoice);
     end if;    
  end if;
end;
/