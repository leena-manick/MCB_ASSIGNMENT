CREATE OR REPLACE PACKAGE body xxbcm_Order_Mgt_pkg AS 
/*Author: Leena Sukhoo
  Creation Date: 3 Feb 2021
  Last Update Date:
  Last Updated by: Leena Sukhoo
  Version:1.0 
Procedure to load PO Lines from XXBCM_ORDER_MGT to XXBCM_Purchase_Order_Line_t and
                  invoices from XXBCM_ORDER_MGT to XXBCM_Invoice_t
*/
   PROCEDURE PO_Line_proc IS
     CURSOR po_line_cur is
     select distinct PO.order_ref PO_Order_Ref, PO_line.PO_Line_Number, PO_line.order_description PO_Line_Description, 
                     PO_line.order_status PO_Line_Status, to_number(PO_line.Order_Line_Amount) PO_Line_Amount,
                     PO_line.invoice_reference, PO_line.invoice_description, to_date(PO_line.invoice_date,'dd-mm-yyyy') invoice_date, PO_line.invoice_status, PO_line.invoice_hold_reason,
                     to_number(replace((replace((replace((REPLACE(lower(invoice_amount), 'o','0')),',','')),'i','1')),'s','5')) invoice_amount
     from
     (
      select order_ref
      from XXBCM_ORDER_MGT
      where instr(order_ref,'-') = 0
     ) PO,
     (
      select order_ref PO_Line_Number,substr(order_ref,1,(instr(order_ref,'-') -1)) ord, order_date,
      to_number(replace((replace((replace((REPLACE(lower(order_line_amount), 'o','0')),',','')),'i','1')),'s','5')) order_line_amount, 
      order_description, order_status, supplier_name,
      --get invoice details
      invoice_reference, invoice_description, invoice_date, invoice_status, invoice_hold_reason, invoice_amount 
      from XXBCM_ORDER_MGT
      where instr(order_ref,'-') > 0
     ) PO_line
     where PO.order_ref = PO_line.ord
    order by PO.order_ref;
    l_key number := 0;
    l_key_invoice number := 0;
   BEGIN
     delete from XXBCM_Purchase_Order_Line_t;
     delete from XXBCM_Invoice_t;
     FOR po_line_rec in po_line_cur 
     LOOP
       dbms_output.put_line('Rec:'||po_line_rec.PO_Line_Number);
       l_key := l_key + 1;
       BEGIN
        insert into XXBCM_Purchase_Order_Line_t values (l_key,
                                                                po_line_rec.PO_Order_Ref, 
                                                                po_line_rec.PO_Line_Number, 
                                                                po_line_rec.PO_Line_Description, 
                                                                po_line_rec.PO_Line_Status,
                                                                po_line_rec.PO_Line_Amount);
       EXCEPTION
       WHEN OTHERS THEN
        dbms_output.put_line('the error is '||SQLERRM);
       END; 
      l_key_invoice := l_key_invoice + 1;
      BEGIN
        insert into XXBCM_Invoice_t values (l_key_invoice,l_key,
                                                                po_line_rec.Invoice_Reference, 
                                                                po_line_rec.Invoice_Description, 
                                                                po_line_rec.Invoice_Date, 
                                                                po_line_rec.Invoice_Status,
                                                                po_line_rec.Invoice_Hold_Reason,
                                                                po_line_rec.Invoice_Amount);
       EXCEPTION
       WHEN OTHERS THEN
        dbms_output.put_line('the error is '||SQLERRM);
       END;                                                          
     END LOOP;
   End PO_Line_proc;
/*Procedure to upload data XXBCM_Purchase_Order_t*/
   PROCEDURE PO_proc IS
     CURSOR po_cur is
     select distinct trim(PO.order_ref) order_ref, PO.order_date, to_number(trim(tot_order.Tot)) order_total_amount, PO.order_description, PO.order_status, 
     PO.supplier_name
     from
     --to get purchase order e.g. PO001 - i.e. the first part of the string before '-' 
     (
      select order_ref,
      to_date(order_date,'dd-mm-yyyy') order_date,order_total_amount, order_description, order_status, supplier_name from XXBCM_ORDER_MGT
      where instr(order_ref,'-') = 0
     ) PO,
     --to get order lines -- 78 lines 
     (
      select order_ref,substr(order_ref,1,(instr(order_ref,'-') -1)) ord,
      order_date,order_total_amount, order_description, order_status, supplier_name from XXBCM_ORDER_MGT
      where instr(order_ref,'-') > 0
     ) PO_line,
     --to get total order amount 
    (
     select substr(order_ref,1,(instr(order_ref,'-') -1)) PO,
     --data cleansing to replace invalid characters 
     sum(to_number(replace((replace((replace((REPLACE(lower(order_line_amount), 'o','0')),',','')),'i','1')),'s','5'))) Tot
     from
     (
      select order_ref, order_line_amount
      from XXBCM_ORDER_MGT 
      --PO lines where status is cancelled has not been consider to get total PO amount 
      where lower(order_status) <> 'cancelled'
      and order_line_amount is not null
     ) total_order
     group by substr(order_ref,1,(instr(order_ref,'-') -1))
    ) tot_order
    where PO.order_ref = PO_line.ord
    and PO_line.ord = tot_order.PO;
   BEGIN
     delete from XXBCM_Purchase_Order_t;
     FOR po_rec in po_cur 
     LOOP
       dbms_output.put_line('Rec:'||po_rec.order_ref||' '||po_rec.supplier_name);
       BEGIN
        insert into XXBCM_Purchase_Order_t values (po_rec.order_ref, 
                                                            po_rec.order_date,
                                                            po_rec.supplier_name, 
                                                            po_rec.order_total_amount
                                                            ,po_rec.order_description, 
                                                            po_rec.order_status);
       EXCEPTION
       WHEN OTHERS THEN
        dbms_output.put_line('the error is '||SQLERRM);
       END;                                                          
     END LOOP;  
   END PO_proc;
   /*procedure to load supplier data from XXBCM_ORDER_MGT to XXBCM_SUPPLIER_T*/
   PROCEDURE Supplier_proc IS
     CURSOR supplier_cur is
     --data cleansing to remove invalid characters   
     select distinct trim(supplier_name) supp_name, trim(supp_contact_name) supp_contact, trim(supp_address) supp_addr,
                replace((replace((replace(lower(supp_contact_number),'i','1')),'s','5')),'o','0') supp_contact_num,
                trim(supp_email) supp_email 
     from XXBCM_ORDER_MGT;
   BEGIN
     delete from XXBCM_SUPPLIER_T;
     FOR supplier_rec in supplier_cur 
     LOOP
       dbms_output.put_line('Rec:'||supplier_rec.supp_name||' '||supplier_rec.supp_contact_num);
       BEGIN
         insert into XXBCM_SUPPLIER_T values (supplier_rec.supp_name, supplier_rec.supp_contact, supplier_rec.supp_addr, 
                                            supplier_rec.supp_contact_num, supplier_rec.supp_email);
       EXCEPTION
       WHEN OTHERS THEN
        dbms_output.put_line('the error is '||SQLERRM);
       END;                                     
     end loop;
   END Supplier_proc;
END xxbcm_Order_Mgt_pkg; 
/