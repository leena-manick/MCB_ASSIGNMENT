CREATE TABLE XXBCM_SUPPLIER_T 
(
Supplier_Name varchar2(2000) not null,
Supp_Contact_Name varchar2(2000) not null,
Supp_Address varchar2(2000) not null,
Supp_Contact_Number varchar2(2000) not null,
Supp_Email varchar2(2000)not null,
CONSTRAINT supplier_pk PRIMARY KEY (Supplier_Name)
);
/

CREATE TABLE XXBCM_Purchase_Order_t
(
PO_Order_Ref varchar2(10),
Order_Date date Not Null,
Supplier_Name varchar2(2000) Not Null,
Order_Total_Amount number(10,2)    Not Null,
Order_Description varchar2(2000) Not Null,
Order_Status varchar2(2000) Not Null,
CONSTRAINT po_pk PRIMARY KEY (PO_Order_Ref)
);
/

CREATE TABLE XXBCM_Invoice_t
(
Invoice_ID number Not null,
PO_Line_ID number Not Null,
Invoice_Reference varchar2(2000),	
Invoice_Description	varchar2(2000),	
Invoice_Date date,	
Invoice_Status varchar2(2000),
Invoice_Hold_Reason	varchar2(2000),	
Invoice_Amount number(10,2),	
CONSTRAINT invoice_pk PRIMARY KEY (invoice_id)
);
/ 

CREATE TABLE XXBCM_Purchase_Order_Line_t
(
PO_Line_ID number Not Null,
PO_Order_Ref varchar2(2000)	Not null,
PO_Line_Number varchar2(2000) Not null,
PO_Line_Description varchar2(2000) Not null,
PO_Line_Status varchar2(2000) Not null,
PO_Line_Amount number(10,2) Not Null,
CONSTRAINT po_line_pk PRIMARY KEY (PO_Line_ID)
);
/