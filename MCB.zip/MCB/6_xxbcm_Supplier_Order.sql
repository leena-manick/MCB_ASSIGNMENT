CREATE or replace procedure xxbcm_Supplier_Order AS
/*Author: Leena Sukhoo
  Creation Date: 4 Feb 2021
  Last Update Date:
  Last Updated by: Leena Sukhoo
  Version:1.0 
Procedure to generate the List of suppliers with their respective number of orders and total amount ordered from them between the period of 01 January 2017 and 31 August 2017
*/
 cursor supplier_cur is
 select s.supplier_name, s.supp_contact_name, supp_contact_number, count(po_order_ref) Total_Orders,
 sum(p.order_total_amount) Order_Total_Amount
 from XXBCM_Supplier_t s, XXBCM_Purchase_Order_t p
 where s.supplier_name = p.supplier_name
 and (order_date >= to_date('01-Jan-2017','dd-mon-yyyy')) and (order_date <= to_date('31-Aug-2017','dd-mon-yyyy'))
 group by s.supplier_name, s.supp_contact_name, supp_contact_number;
 cursor supp_cont_cur(l_cont varchar2) is
 select val from
    (
     with cont as (select l_cont as str from dual)
     select level as n, regexp_substr(str,'[^,]+',1,level) as val
     from cont
     connect by regexp_substr(str,'[^,]+',1,level) is not null 
    );
 rec_supp supplier_cur%ROWTYPE;
 rec_cont supp_cont_cur%ROWTYPE;
 l_contact number;
 l_temp_contact varchar2(100);
 TYPE cont_list_arr is table of varchar2(200) index by pls_integer;
 cont_list cont_list_arr;
 l_counter integer := 1;
begin
  delete from xxbcm_supplier_order_cont;
  open supplier_cur;
  fetch supplier_cur into rec_supp;
  while supplier_cur%found
  loop
    open supp_cont_cur(rec_supp.supp_contact_number);
    fetch supp_cont_cur into rec_cont;
    while supp_cont_cur%found
    loop
      l_temp_contact := replace((replace(trim(rec_cont.val),'.','')),' ','');
      l_contact := to_number(l_temp_contact);
      if length(l_temp_contact) = 7 then
        l_temp_contact := replace(to_char(l_contact,'999,9999'),',','-');
      else
        l_temp_contact := replace(to_char(l_contact,'9999,9999'),',','-');  
      end if;
      dbms_output.put_line(rec_supp.supplier_name||'*'||rec_supp.supp_contact_name||'*'||l_temp_contact||'*'||
      rec_supp.Total_Orders||'*'||rec_supp.Order_Total_Amount);
      if (supp_cont_cur%rowcount) = 1 then
         cont_list(1) := l_temp_contact;
      else 
        if (supp_cont_cur%rowcount) = 2 then
           cont_list(2) := l_temp_contact;  
        end if;        
      end if; 
      fetch supp_cont_cur into rec_cont;
    end loop;
    insert into xxbcm_supplier_order_cont values (rec_supp.supplier_name,rec_supp.supp_contact_name,cont_list(1),cont_list(2),rec_supp.Total_Orders,
               rec_supp.Order_Total_Amount); 
    cont_list(1) := ' ';
    cont_list(2) := ' ';
    close supp_cont_cur;
    fetch supplier_cur into rec_supp;
  end loop;
  close supplier_cur;
end;