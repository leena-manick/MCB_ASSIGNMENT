CREATE OR REPLACE PACKAGE xxbcm_Order_Mgt_pkg AS 
   PROCEDURE PO_Line_proc;
   PROCEDURE PO_proc;
   PROCEDURE Supplier_proc;   
END xxbcm_Order_Mgt_pkg;